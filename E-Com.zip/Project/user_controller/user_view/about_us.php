<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="../user_css/about.css">
</head>
<body bgcolor="#BBD0F9">
    <h1 align="center">Star Cineplex</h1>
    <fieldset>
<p>
Welcome to Star cineplex, your number one source for all movies. We're dedicated to providing you the best of Movies an facielities, with a focus on dependability. customer service.
We're working to turn our passion for customers into a booming online store. We hope you enjoy our products as much as we enjoy offering them to you.
<br><br>
Sincerely,
[Asif Zaman]


</p>
    </fieldset>
    <p align="center">copyright Ⓒ 1999 by star cineplex authority </p>
    
    <div id="show">
    <button class="butt" id="butt" onclick="loadDoc()">Contributors</button>
    </div>
   
    <a align="center" href="homepage.php">Homepage</a>

    <script src=" ../user_js/about.js "></script>
    
</body>


</html>