<?php

echo "<p>Customer Panel : Asif Zaman </p>";
echo "<p>Seller Panel : Angela Sarkar </p>";
echo "<p>Manager : Rubaba Binte </p>";
echo "<p>Admin : Rayied Hussain  </p>";





?>