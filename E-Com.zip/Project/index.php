<?php
header("Location: user_view/homepage.php");
?>