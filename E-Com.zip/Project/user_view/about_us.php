<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="../user_css/about.css">
</head>
<body bgcolor="#BBD0F9">
    <h1 align="center">About Us</h1>
    <fieldset>
<p>
Welcome to our website. We're dedicated to providing you the best Phone with a great values.
We're working make our customers happy . We hope you enjoy our products as much as we enjoy offering them to you.
<br><br>
Sincerely,
[Tanvir Ahmed]


</p>
    </fieldset>
    <p align="center">copyright Ⓒ 2022 by Tanvir </p>
    
  
   
    <a align="center" href="homepage.php">Homepage</a>

    <script src=" ../user_js/about.js "></script>
    
</body>


</html>